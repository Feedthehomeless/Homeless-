document.addEventListener('DOMContentLoaded', () => {
    const walletAddresses = {
        btc: 'your-bitcoin-wallet-address',
        eth: 'your-ethereum-wallet-address',
        usdt: 'your-tether-wallet-address'
    };

    const copyButton = document.getElementById('copy-wallet-address');
    const donateButton = document.getElementById('donate-now');
    const cryptoSelect = document.getElementById('crypto-select');

    copyButton.addEventListener('click', () => {
        const selectedCrypto = cryptoSelect.value;
        const walletAddress = walletAddresses[selectedCrypto];
        navigator.clipboard.writeText(walletAddress).then(() => {
            alert('Wallet address copied to clipboard!');
        });
    });

    donateButton.addEventListener('click', () => {
        const selectedCrypto = cryptoSelect.value;
        const walletAddress = walletAddresses[selectedCrypto];
        if (walletAddress) {
            window.open(`https://www.example.com/donate?address=${walletAddress}`, '_blank');
        } else {
            alert('Please select a cryptocurrency.');
        }
    });
});